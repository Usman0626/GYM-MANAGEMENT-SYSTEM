#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<unistd.h>



/*****************************************************
                FUNCTION PROTOTYPES
******************************************************/

void Home_page(char *c_loginid, char *c_password);

void title1();
void title();
void add_member();
int exit();
void search_member();
void addTrainer();
void search_trainers();
void Display_supplements_bill();
void supplement_store();
 void display_members();
 void display_trainers();
typedef struct member {

    char name[50];
    char gender;
    int age;
    int number;
    float weight;
    float height;

}member;

// Structure to represent a trainer
typedef struct Trainer {

    char name[50];
    char gender;
    int age;
    char expertise[50];
}trainer;

// Structure to represent a supplement
struct Supplement {
    int id;
    char name[50];
    float price;
};

// Structure to represent a membership plan
struct Plan {
    int id;
    char name[50];
    float price;
};
typedef struct Superstore{

    int id;
    char name[50];

    float price;

}store;



/*****************************************************
               MAIN FUNCTION
******************************************************/

int main() {
	char c_loginid[] = "project";
    char c_password[] = "project987";
    Home_page(c_loginid, c_password);

    return 0;
}

/*****************************************************
function to Display title
******************************************************/
void title()
{
    printf("\n\n\n");
    printf("\n\t\t\t  /////////////////////////////////////////////////////////\n");
    printf("  \t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
    printf("\n\t\t\t        =                  WELCOME                  =");
    printf("\n\t\t\t        =                    TO                     =");
    printf("\n\t\t\t        =                    GYM                    =");
    printf("\n\t\t\t        =                 MANAGEMENT                =");
    printf("\n\t\t\t        =                  SYSTEM                   =");
    printf("\n\t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
    printf("\n\t\t\t  ////////////////////////////////////////////////////////\n");

 }

/*****************************************************
function to Display title for store
******************************************************/
void title1()
{
    printf("\n\n\n");
    printf("\n\t\t\t  /////////////////////////////////////////////////////////\n");
    printf("  \t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
    printf("\n\t\t\t        =                 WELCOME                  =");
    printf("\n\t\t\t        =                    TO                     =");
    printf("\n\t\t\t        =                 SUPPLEMENT                  =");
    printf("\n\t\t\t        =                  SHOPPING                =");
    printf("\n\t\t\t        =                   STORE                 =");
    printf("\n\t\t\t        =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
    printf("\n\t\t\t  ////////////////////////////////////////////////////////\n");

 }



/*****************************************************
                       HOME PAGE
******************************************************/

void  Home_page(char *c_loginid, char *c_password) {
	title();
    char login[7], password[10];
        int choice;
    for(int i=1;i<=3;i++) {
        printf("Enter the login ID: ");
        scanf("%s", login);// apply fgets
        printf("Enter the password: ");
        scanf("%s", password);// apply fgets
        if(strcmp(login, c_loginid) == 0 && strcmp(password, c_password) == 0) {
            printf("login Successfull");
              system("cls");
    do {
        printf("\n////////---MENU---////////\n");
        printf("1. Add Member\n");
        printf("2. Display Members\n");
        printf("3. Search Member\n");
        printf("4. Add Trainer\n");
        printf("5. Search Trainers\n");
        printf("6. Display Trainer\n");
        printf("7. Display Supplements bill\n");

        printf("8. Exit\n");
        printf("Enter your choice: ");


       // scanf("%d", &choice);

         while (1) {
        printf("Enter your choice (1-8): ");

        // Read the input
        if (scanf("%d", &choice) == 0) {
            // Clear the input buffer
            while (getchar() != '\n');
            printf("Invalid input. Please enter an integer.\n");
        } else {
            // Check if the choice is within the valid range
            if (choice < 1 || choice > 8) {
                printf("Invalid choice. Please enter a value between 1 and 8.\n");
            } else {
                // Valid choice entered, exit the loop
                break;
            }
        }
    }

    // Proceed with the program based on the valid choice

        switch (choice) {
            case 1:
                add_member();
                break;
            case 2:
                display_members();
                break;
            case 3:
                search_member();
                break;
            case 4:
                addTrainer();
                break;
            case 5:
                search_trainers();
                break;
            case 6:
               display_trainers();
                break;
            case 7:
               Display_supplements_bill();
                break;
            case 8:
                printf("Exiting the program...\n");
                break;
            default:
            	{

                printf("Invalid choice. Please try again.\n");
                break;
            }
        }
    } while (choice != 8);
            break;
        } else if(i == 3) {
            printf("Your account is suspended.\n");
            break;
        } else {
            printf("Incorrect Password\n");
        }
    }
}

/*****************************************************
ADD MEMBER FUNCTION
******************************************************/
void add_member() {
    member members;
    char opt;
    FILE *members_file;

    members_file = fopen("members.txt", "a");
    if (members_file == NULL) {
        printf("File cannot be created\n");
        return;
    }

    printf("\nEnter Name of Member: ");
    scanf("%s", members.name);

    printf("\nEnter Gender (M or F): ");
    scanf(" %c", &members.gender);

    printf("\nEnter Age: ");
    scanf("%d", &members.age);

    printf("\nEnter Weight: ");
    scanf("%f", &members.weight);

    printf("\nEnter Height: ");
    scanf("%f", &members.height);

    fprintf(members_file,  "\t%s \t%c \t%d \t %.2f \t%.2f \t \n", members.name, members.gender, members.age, members.weight, members.height);
    fclose(members_file);
     char choice;

     char choice1;

     trainer trainers;
     //
     while (1) {
        printf("\nDo you need a personal Trainer for Your Help? (Y/N): ");
        scanf(" %c", &opt);

        // Check if the input is valid
        if (opt == 'Y' || opt == 'y' || opt == 'N' || opt == 'n') {
            break; // Exit the loop if input is valid
        } else {
            printf("Invalid input. Please enter Y or N.\n");
        }
    }

    if (opt == 'Y' || opt == 'y') {
        // Code for assigning a trainer...




   // scanf(" %c", &opt);



        char trainer_name[50];

       int trainer_found = 0;


        // Display available trainers
        printf("\nAvailable Trainers:\n");
        FILE *trainer_file = fopen("trainers.txt", "r");
        if (trainer_file == NULL) {
            printf("Error: Trainer file not found!\n");
            return;
        }
        while (fscanf(trainer_file, "%s %c %d %s\n", trainers.name, &trainers.gender, &trainers.age, trainers.expertise) != EOF) {
            printf("%s\n", trainers.name);
        }
        fclose(trainer_file);

        // Ask the user to choose a trainer
        printf("Enter the Name of trainer you want: ");
        scanf("%s", trainer_name);

        // Check if the chosen trainer exists
        trainer_file = fopen("trainers.txt", "r");
        while (fscanf(trainer_file, "%s %c %d %s\n", trainers.name, &trainers.gender, &trainers.age, trainers.expertise) != EOF) {
            if (strcmp(trainer_name, trainers.name) == 0) {
                printf("Trainer %s is assigned to you.\n", trainers.name);
                trainer_found = 1;
                break;
            }
        }
        fclose(trainer_file);

        if (!trainer_found) {
            printf("Trainer not found or unavailable.\n");
        }
    }

    // Ask if the member wants to purchase supplements
    while (1) {
        printf("\nDo you want to purchase supplements? (Y/N): ");
        scanf(" %c", &opt);

        // Check if the input is valid
        if (opt == 'Y' || opt == 'y' || opt == 'N' || opt == 'n') {
            break; // Exit the loop if input is valid
        } else {
            printf("Invalid input. Please enter Y or N.\n");
        }
    }

    if (opt == 'Y' || opt == 'y') {
        // Code for supplement purchase...

        supplement_store();
    }

}

/*****************************************************
function to SEARCH MEMBER
******************************************************/

void search_member() {
    int test = 0;
    char check_name[20];
    char opt1;

    printf("Enter the name of member: ");
    scanf("%s", check_name);

    member members1;
    FILE *members_file = fopen("members.txt", "r");

    if (members_file == NULL) {
        printf("File cannot be opened\n");
        return;
    }

    while (fscanf(members_file, "%s %c %d %f %f \n", members1.name, &members1.gender, &members1.age, &members1.weight, &members1.height) != EOF) {
        if (strcmp(check_name, members1.name) == 0) {
            test = 1;
            printf("\n\t\tRecord Found\n\n");
            printf("Here's the Record that you are searching for:\n\n");
            printf("---------------------------------------------------------------------------\n");
            printf("Name\t\tGender\t\tAge\t\tWeight\t\tHeight\t\n");
            printf("----------------------------------------------------------------------------\n");
            printf("%s\t\t%c\t\t%d\t\t%.2f\t\t%.2f\t\t \n", members1.name, members1.gender, members1.age, members1.weight, members1.height);
            break; // Exit the loop after finding the record
        }
    }

    fclose(members_file);

    if (test == 0) {
        printf("\n\t\tRECORD NOT FOUND!\n");
    }

    exit();
}
/*****************************************************
function to DISPLAY MEMBERS LIST
******************************************************/

  void display_members() {
    int opt1;
    member members2;
    FILE* members_file;
    members_file = fopen("members.txt", "r");
    if (members_file == NULL) {
        printf("File cannot be opened\n");
        return;
    }
    printf("---------------------------------------------------------------------------\n");
            printf("Name\t\tGender\t\tAge\t\tWeight\t\tHeigh\n");
            printf("----------------------------------------------------------------------------\n");
    while (fscanf(members_file, "%s %c %d %f %f %d\n", members2.name, &members2.gender, &members2.age, &members2.weight, &members2.height, &members2.number) != EOF) {

        printf("%s\t\t%c\t\t %d\t\t%.2f\t\t%.2f\n", members2.name, members2.gender, members2.age, members2.weight, members2.height);
    }
    fclose(members_file);

   exit();
}

/*****************************************************
function to ADD TRAINER
******************************************************/

void addTrainer()
{
 trainer trainers;
  char opt;
    FILE *trainers_file;

    trainers_file = fopen("trainers.txt", "a");
    if (trainers_file == NULL) {
        printf("File cannot be created\n");
        return;
    }


    printf("\n \t \tEnter Name of TRAINER: ");
    scanf("%s", trainers.name);

    printf("\n\t \tEnter Gender (M or F): ");
    scanf(" %c", &trainers.gender);

    printf("\n \t \tEnter Age: ");
    scanf("%d", &trainers.age);


 printf("\n\t \t Enter the expertise \n ");
    scanf(" %s", trainers.expertise);



    fprintf(trainers_file, "%s %c %d  %s\n", trainers.name, trainers.gender, trainers.age,trainers.expertise);
    fclose(trainers_file);

    exit();
}


/*****************************************************
function to SEARCH TRAINER
******************************************************/
void search_trainers()
{
	int test = 0;
    char check_name[20];
    char opt1;

    printf("Enter the name of Trainer: ");
    scanf("%s", check_name);

    trainer trainers1;
    FILE *trainers_file = fopen("trainers.txt", "r");

    if (trainers_file == NULL) {
        printf("File cannot be opened\n");
        return;
    }

while (fscanf(trainers_file, "%s %c %d %s\n", trainers1.name, &trainers1.gender, &trainers1.age, trainers1.expertise) != EOF) {
        if (strcmp(check_name, trainers1.name) == 0) {
            test = 1;
            printf("\n\t\tRecord Found\n\n");
            printf("Here's the Record that you are searching for:\n\n");
            printf("---------------------------------------------------------------------------\n");
            printf("Name\t\tGender\tAge\tExpertise\n");
            printf("----------------------------------------------------------------------------\n");
            printf("%s\t\t%c\t%d\t%s\n", trainers1.name, trainers1.gender, trainers1.age, trainers1.expertise);
            break; // Exit the loop after finding the record
        }
    }

    fclose(trainers_file);

    if (test == 0) {
        printf("\n\t\tRECORD NOT FOUND!\n");
    }

   exit();
}

/*****************************************************
function to DISPLAY TRAINER
******************************************************/


void display_trainers() {
    int opt1;
    trainer trainers2;
    FILE* trainers_file;

    trainers_file = fopen("trainers.txt", "r");
    if (trainers_file == NULL) {
        printf("File cannot be opened\n");
        return; // Return if file cannot be opened
    }
printf("---------------------------------------------------------------------------\n");
        printf("Name\t\tGender\tAge\tExpertise\n");
        printf("----------------------------------------------------------------------------\n");
    while (fscanf(trainers_file, " %s %c %d %s\n",trainers2.name, &trainers2.gender, &trainers2.age, trainers2.expertise) !=EOF) {

        printf("%s\t\t%c\t%d\t%s\n", trainers2.name, trainers2.gender, trainers2.age, trainers2.expertise);
    }

    fclose(trainers_file);
    exit();
}

/*****************************************************
function to SUPPLEMENT STORE
******************************************************/

void supplement_store()
{
	title1();

		store stores;
		printf(" \n \t \t Enter you ID \t");
		scanf("%d",&stores.id);
		printf(" \n \t \t Enter you name ");
		scanf("%s",stores.name);// apply fgets

	int choice;
	float bill=0;
	int quantity;
	 int whey_protein_quantity=2000;

	 int pre_workout_quantity=5000;

	 int fat_burner_quantity=7000;

	int mass_gainer_quantity=1500;

	int creatine_quantity=2000;

	 int protein_bars_quantity=15000;

	const float whey_protein_price=160;

	const float pre_workout_price=30;

	const float fat_burner_price=15;

	const float mass_gainer_price=200;

	const float creatine_price=200;

	const float protein_bars=5;

	printf("\n  What you wanna buy ");

	printf(" \n1.Whey_protein\n 2.Pre_workout\n 3.Fat_burners \n 4.Mass_Gainers \n 5.Creatine \n 6.Protein Bars \n");
//	scanf("%d",&choice);
	 while (1) {
        printf("Enter your choice (1-6): ");

        // Read the input
        if (scanf("%d", &choice) == 0) {
            // Clear the input buffer
            while (getchar() != '\n');
            printf("Invalid input. Please enter an integer.\n");
        } else {
            // Check if the choice is within the valid range
            if (choice < 1 || choice > 8) {
                printf("Invalid choice. Please enter a value between 1 and 6.\n");
            } else {
                // Valid choice entered, exit the loop
                break;
            }
        }
    }



	switch(choice)
	{

		case 1:
			{
					printf("\n \t \tEnter the quantity of Whey protien you wanna have \t");
					scanf("%d",&quantity);
				if(whey_protein_quantity>=quantity)
				{

					bill=quantity*whey_protein_price;

				}

				else
				{
					printf(" \n\t \tSorry the stock is finished \t");
				}
				break;
			}
				case 2:
			{
					printf("\n \t \tEnter the quantity of pre workout you wanna have \t");
					scanf("%d",&quantity);
				if(pre_workout_quantity>=quantity)
				{

					bill=quantity*pre_workout_price;

				}
					else
				{
					printf(" \n\t \tSorry the stock is finished \t");
				}
				break;

			}

				case 3:
			{
				printf("\n \t \tEnter the quantity of fat burner you wanna have \t");
					scanf("%d",&quantity);
				if(fat_burner_quantity>=quantity)
				{

					bill=quantity*fat_burner_price;
					break;
				}
					else
				{
					printf(" \n\t \tSorry the stock is finished \t");
				}
				break;

			}
				case 4:
			{
					printf("\n \t \tEnter the quantity of mass gainer you wanna have \t");
					scanf("%d",&quantity);
				if(mass_gainer_quantity>=quantity)
				{

					bill=quantity*mass_gainer_price;

				}
					else
				{
					printf(" \n\t \tSorry the stock is finished \t");
				}
				break;
			}
					case 5:
			{
					printf("\n \t \tEnter the quantity of creatine packs you wanna have \t");
					scanf("%d",&quantity);
				if(creatine_quantity>=quantity)
				{

					bill=quantity*creatine_price;

				}
				else
				{
					printf(" \n\t \tSorry the stock is finished \t");
				}
				break;
			}
					case 6:
			{
				printf("\n \t \tEnter the quantity of protein bars you wanna have \t");
					scanf("%d",&quantity);
				if(mass_gainer_quantity>=quantity)
				{

					bill=quantity*protein_bars;

				}
				else
				{
					printf("Sorry the stock is finished \n");
				}

				break;

			}
			default:
				printf(" \n\t \t Invalid choice choose option between (1-6)");



}
printf("\t \t THANKS FOR SHOPPING \n \t \t your total bill is %.2f",bill);
 stores.price=bill;

FILE *superstore_file;

    superstore_file = fopen("superstore.txt", "a");
    if (superstore_file == NULL) {
        printf("File cannot be created\n");
        return;
    }
  fprintf(superstore_file, "%d  %s %f \n", stores.id,stores.name,stores.price);
    fclose(superstore_file);

    exit();


}

/*****************************************************
function to DISPLAY SUPPLEMENT BILL
******************************************************/

	void Display_supplements_bill()
	{
		int opt1;
		store stores1;
		FILE *superstore_file = fopen("superstore.txt", "r");

    if (superstore_file == NULL) {
        printf("File cannot be opened\n");
        return;
    }
  printf("ID\t\tNAME\t\tPENDING BLL\t\t\n");

    while (fscanf(superstore_file, "%d  %s %f \n", &stores1.id,stores1.name,&stores1.price) != EOF) {



          printf("%d\t\t%s\t\t%f \n", stores1.id,stores1.name,stores1.price);

    }

    fclose(superstore_file);

exit();
}




 /*****************************************************
        FUNCTION FOR EXIT
******************************************************/

int exit()
{
	int opt1;
	do {
        printf("\n\tEnter E to exit: ");
        scanf(" %c", &opt1);
        if (opt1 == 'e' || opt1 == 'E') {
            printf("EXITING....\n\n");
            sleep(1);
            break;
        }
        printf("ERROR! INVALID INPUT\n");
    } while (opt1 != 'e' && opt1 != 'E');
}
